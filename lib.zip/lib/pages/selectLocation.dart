import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:geolocator/geolocator.dart';
import 'package:my_app/buttons/Elv_button.dart';
import 'package:my_app/pages/secpage.dart';
import 'package:my_app/url/builder.dart';

class GoogleMapsPage extends StatefulWidget {
  @override
  _GoogleMapsPageState createState() => _GoogleMapsPageState();
}

class _GoogleMapsPageState extends State<GoogleMapsPage> {
  final places =
      GoogleMapsPlaces(apiKey: 'AIzaSyDWZMm53Euuzmg7H0UGbY5TFN-O7LBmf8Y');
  GoogleMapController? _controller;
  TextEditingController _searchController = TextEditingController();
  LatLng? _currentLocation;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onMapCreated(GoogleMapController controller) {
    setState(() {
      _controller = controller;
    });
  }

  @override
  void initState() {
    super.initState();
    _getCurrentLocation().then((value) {
      _moveToCurrentLocation(value);
    }).catchError((error) {
      print(error);
    });
  }

  void _searchLocation(String searchTerm) async {
    PlacesSearchResponse response = await places.searchByText(searchTerm);
    if (response.isOkay) {
      // Extract location data from the response and handle it
      List<PlacesSearchResult> results = response.results;
      // For simplicity, let's just print the first result
      print(results.first);
    } else {
      print('Search failed: ${response.errorMessage}');
    }
  }

  Future<Position> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error("Location services are disabled.");
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error("Location permissions are denied.");
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return Future.error("Location permissions are permanently denied.");
    }
    return await Geolocator.getCurrentPosition();
  }

  void _moveToCurrentLocation(Position position) {
    final LatLng currentLatLng = LatLng(position.latitude, position.longitude);
    _controller?.animateCamera(CameraUpdate.newLatLng(currentLatLng));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffeff7f1),
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff052C47)),
        title: Text(
          'Choose your current location',
          style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              fontFamily: "Teachers"),
        ),
        backgroundColor: Color(0xffeff7f1),
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: LatLng(37.42796133580664, -122.085749655962),
              zoom: 14.0,
            ),
            onMapCreated: _onMapCreated,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
          ),
          Positioned(
            top: 10.0,
            left: 10.0,
            right: 10.0,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 1,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 20.0,
            left: 20.0,
            right: 20.0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElvButtons(
                    onPressed: () {
                      _getCurrentLocation().then((value) {
                        BuilderClass().setLng(value.longitude);
                        BuilderClass().setLat(value.latitude);
                        print(BuilderClass().buildUrl());
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return SecondPage();
                }));
                        _moveToCurrentLocation(value);
                      }).catchError((error) {
                        print(error);
                      });
                    },
                    text: 'Get Current Location'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
